
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import ni.edu.uca.loginconsql.LoginActivity
import ni.edu.uca.loginconsql.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Llamar al LoginActivity
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)

        // Llamar al AppDatabase
        val userDao = AppDatabase(this).getUserDao()
        // Realizar operaciones en la base de datos...
    }
}