import android.content.Context
import android.widget.Toast
import ni.edu.uca.loginconsql.User
import ni.edu.uca.loginconsql.UserDao
import java.sql.*

class AppDatabase(context: Context) {
    private val connection: Connection

    init {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
        Toast.makeText(context, "Conectando a la base de datos...", Toast.LENGTH_SHORT).show()
        connection = DriverManager.getConnection(
            "jdbc:sqlserver://DESKTOP-Q4UIS59;databaseName=Autenticacion",
            "sa",
            "1234"
        )
        if (!connection.isClosed) {
            Toast.makeText(context, "Conexión exitosa", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Error de conexión", Toast.LENGTH_SHORT).show()
        }
    }

    fun getUserDao(): UserDao {
        return object : UserDao {
            override fun login(username: String, password: String): User? {
                val statement = connection.prepareStatement(
                    "SELECT * FROM users WHERE username = ? AND password = ?"
                )
                statement.setString(1, username)
                statement.setString(2, password)
                val resultSet = statement.executeQuery()
                return if (resultSet.next()) {
                    User(
                        resultSet.getInt("id"),
                        resultSet.getString("username"),
                        resultSet.getString("password")
                    )
                } else {
                    null
                }
            }
        }
    }
}