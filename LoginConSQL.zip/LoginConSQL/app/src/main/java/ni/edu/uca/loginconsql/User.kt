package ni.edu.uca.loginconsql

data class User(

    val id: Int,
    val username: String,
    val password: String

)
